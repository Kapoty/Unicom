import React from "react";

import {withStyles, useTheme} from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import BagProduct from './BagProduct';
import TextField from '@material-ui/core/TextField';
import Divider from '@material-ui/core/Divider';

const useStyles = (theme) => ({
	root: {
		width: '100%',
		display: 'flex',
		flexWrap: 'wrap',
		justifyContent: 'center',
		marginTop: theme.spacing(2),
		flexDirection: "column",
	},
	cards: {
		display: 'flex',
		flexWrap: 'wrap',
		justifyContent: 'center',
	},
	button: {
	},
	nameSection: {
		display: 'flex',
		justifyContent: 'center',
	},
	whatsappSection: {
		display: 'flex',
		justifyContent: 'center',
	},
	messageSection: {
		margin: theme.spacing(1),
		display: 'flex',
		justifyContent: 'center',
	},
	messageArea: {
		width: '100%',
		maxWidth: '400px',
	},
	paperSection: {
		margin: theme.spacing(1),
		display: 'flex',
		justifyContent: 'center',
	},
	paper: {
		padding: theme.spacing(1),
		display: 'flex',
		justifyContent: 'center',
		flexDirection: 'column',
		boxSizing: 'border-box',
		maxWidth: '400px',
	}
});

class Bag extends React.Component {

	constructor(props) {
		super(props);
		this.state = {name: ''};
		this.openWhatsapp = this.openWhatsapp.bind(this);
		this.message = this.message.bind(this);
	}

	message() {
		let message = `Olá, tudo bem?\n
Meu nome é *${this.state.name}*\n
Gostaria de saber mais sobre os seguintes produtos:\n\n`;
		this.props.bag.products.forEach((product) => {
			message += `*${product.name}* (COD. ${product.code})\n`
		});
		return message;
	}

	openWhatsapp() {
		try {
		let url = "https://api.whatsapp.com/send/?phone=05562991765603&text=" + this.message();
		var encoded = encodeURI(url);
		window.open(encoded, '_blank');
	}
	catch (e) {
		console.log(e);
	}
	}

	render() {
		const { classes } = this.props;
		return <React.Fragment>
			<div className={classes.root}>
				<Typography variant="h4" align='center' gutterBottom style={{width: '100%'}}>
					Sacola
				</Typography>
				{(this.props.bag.products.length != 0) ? <React.Fragment>
						<div className={classes.cards}>
							{this.props.bag.products.map((product) =>
								<BagProduct key={product.id} product={product} history={this.props.history}
									deleteProductFromBag={this.props.deleteProductFromBag}/>)}
						</div>
						<div className={classes.paperSection}>
							<Paper elevation={1} className={classes.paper}>
								<div className={classes.nameSection}>
									<TextField
										fullWidth
										onChange={(e) => this.setState({name: e.target.value})}
										margin="normal"
										id="name"
										label="Digite seu nome"
										value={this.state.name}
										InputProps={{
											inputProps: {
												maxLength: 255
											}
										}}
										placeholder=""
									/>
								</div>
								<div className={classes.whatsappSection}>
									<Button variant="contained"
											color="primary"
											onClick={this.openWhatsapp}
											className={classes.button}
											disabled={this.state.name == ''}
									>
										Clique aqui para dar prosseguimento ao seu atendimento pelo Whatsapp
									</Button>
								</div>
							</Paper>
						</div>
						{/*<Typography align='center'>
						<p>Ou nos envie a mensagem abaixo para nosso Whatsapp</p>
						</Typography>
						<div className={classes.messageSection}>
							<textarea rows="10" className={classes.messageArea} readonly value={this.message()}></textarea>
						</div>*/}
					</React.Fragment> : <Typography align='center'>
						<p>Os produtos que você adicionar na sua sacola aparecerão aqui.</p>
						</Typography>}
			</div>
		</React.Fragment>
	}

}

export default withStyles(useStyles)(Bag)