var config = {
	apiURL: "https://alternativa.centesima.art.br:3000/api/",
	mediaURL: "https://alternativa.centesima.art.br:3000/media/",
}

module.exports = config;