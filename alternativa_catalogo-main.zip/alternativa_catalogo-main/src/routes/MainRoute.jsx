
import React from "react";
import ReactDOM from "react-dom";

import Config from "../config/Config";
import Cookies from 'universal-cookie';
const cookies = new Cookies();

import { createTheme, ThemeProvider } from '@material-ui/core/styles';

import Slide from '@material-ui/core/Slide';
import Snackbar from '@material-ui/core/Snackbar';

import BottomNav from '../components/BottomNav';
import CustomAppBar from '../components/CustomAppBar';
import CookiesDialog from '../components/CookiesDialog';
import Catalog from '../components/Catalog';
import FilterDialog from '../components/FilterDialog';
import InternalPage from '../components/InternalPage';
import ProductDialog from '../components/ProductDialog';
import Bag from '../components/Bag';

import * as ls from 'local-storage';

const theme = [];

theme[0] = createTheme({
	palette: {
		primary: {
			main: "#f9a825",
		},
		secondary: {
			main: "#1565c0",
		}
	}
});

theme[1] = createTheme({
	palette: {
		primary: {
			main: "#1565c0",
		},
		secondary: {
			main: "#f9a825",
		}
	}
});

const Transition = React.forwardRef(function Transition(props, ref) {
	return <Slide direction="right" ref={ref} {...props} />;
});

export default class MainRoute extends React.Component {

	constructor(props) {
		super(props);
		this.state = {
			lastPage: "/",
			cookiesDialogOpened: cookies.get('cookiesDialog') == undefined,
			categoriesLoaded: false, categories: [],
			productsLoaded: false, products: [],
			filter: {
				order: 1,
				name: ''
			}, filterDialogOpened: false,
			bag: {
				name: '',
				products: []
			},
			addedToBag: false, addedToBagInfo: {name: ''},
			theme: 1,
		};

		this.getCategoriesList = this.getCategoriesList.bind(this);
		this.getProductsList = this.getProductsList.bind(this);

		this.setFilter = this.setFilter.bind(this);
		this.openFilter = this.openFilter.bind(this);
		this.closeFilter = this.closeFilter.bind(this);

		this.addProductToBag = this.addProductToBag.bind(this);
		this.deleteProductFromBag = this.deleteProductFromBag.bind(this);
		this.clearBagProducts = this.clearBagProducts.bind(this);
		this.loadBagProductsFromStorage = this.loadBagProductsFromStorage.bind(this);
		this.saveBagProductsToStorage = this.saveBagProductsToStorage.bind(this);
		this.closeAddToBag = this.closeAddToBag.bind(this);
		this.updateBagProducts = this.updateBagProducts.bind(this);

		this.closeCookiesDialog = this.closeCookiesDialog.bind(this);

		this.changeTheme = this.changeTheme.bind(this);
	}

	componentDidMount() {
		this.getCategoriesList();
		this.getProductsList();
		this.loadBagProductsFromStorage();
	}

	/* get data from API */

	getCategoriesList() {
		this.setState({categories: [], categoriesLoaded: false});
		fetch(Config.apiURL + "categories", {
			method: "GET"
		})
		.then((resp) => {
			if (resp.status != 200)
				setTimeout(this.getCategoriesList, 5000);
			else resp.json().then((data) => {
				data.categories.sort((c1, c2) => c1.position - c2.position);
				this.setState({categories: data.categories, categoriesLoaded: true});
			})
		})
		.catch((e) => {
			setTimeout(this.getCategoriesList, 5000);
			console.log(e);
		});
	}

	getProductsList() {
		this.setState({products: [], productsLoaded: false});
		fetch(Config.apiURL + "products", {
			method: "GET"
		})
		.then((resp) => {
			if (resp.status != 200)
				setTimeout(this.getProductsList, 5000);
			else resp.json().then((data) => {
				this.state.products = data.products;
				this.setState({productsLoaded: true});
				this.updateBagProducts();
			})
		})
		.catch((e) => {
			setTimeout(this.getProductsList, 5000);
			console.log(e);
		});
	}

	/* Filter */

	setFilter(order, name) {
		this.setState({filter: {order: order, name: name}, filterDialogOpened: false});
	}

	openFilter() {
		this.setState({filterDialogOpened: true});
	}

	closeFilter() {
		this.setState({filterDialogOpened: false});
	}

	/* Bag */

	addProductToBag(product) {
		let i;
		let number_of_products = this.state.bag.products.length;
		for (i=0; i<number_of_products; i++)
			if (this.state.bag.products[i].id == product.id)
				break;
		if (i == number_of_products) {
			this.state.bag.products.push({
				id: product.id,
				code: product.code,
				name: product.name,
				price: product.price,
				installment_value: product.installment_value,
				installment_qty: product.installment_qty,
				cover: product.cover,
			});
			this.state.addedToBag = true; 
			this.state.addedToBagInfo = {name: product.name};
			this.saveBagProductsToStorage();
			this.forceUpdate();
		}
	}

	deleteProductFromBag(productId) {
		let i;
		let number_of_products = this.state.bag.products.length;
		for (i=0; i<number_of_products; i++)
			if (this.state.bag.products[i].id == productId) {
				this.state.bag.products.splice(i, 1);
				this.saveBagProductsToStorage();
				this.forceUpdate();
			}
	}

	clearBagProducts() {
		this.state.bag.products = [];
		this.saveBagProductsToStorage();
		this.forceUpdate();
	}

	updateBagProducts() {
		let number_of_products = this.state.products;
		let keepList = [];
		this.state.bag.products.forEach((product, i) => {
			for (let j=0; j<this.state.products.length; j++)
				if (this.state.products[j].id == product.id) {
					this.state.bag.products[i] = {
						id: product.id,
						code: this.state.products[j].code,
						name: this.state.products[j].name,
						price: this.state.products[j].price,
						installment_value: this.state.products[j].installment_value,
						installment_qty: this.state.products[j].installment_qty,
						cover: this.state.products[j].cover,
					};
					keepList.push(product.id);
					break;
				}
		});
		this.state.bag.products = this.state.bag.products.filter((product) => keepList.includes(product.id));
		this.saveBagProductsToStorage();
		this.forceUpdate();
	}

	loadBagProductsFromStorage() {
		if (ls('bagProducts') == undefined)
			ls('bagProducts', JSON.stringify([]));
		this.state.bag.products = JSON.parse(ls('bagProducts'));
		this.forceUpdate();
	}

	saveBagProductsToStorage() {
		ls('bagProducts', JSON.stringify(this.state.bag.products));
	}

	closeAddToBag() {
		this.setState({addedToBag: false});
	}

	closeCookiesDialog() {
		cookies.set('cookiesDialog', '0', {maxAge: 7 * 86400});
		this.setState({cookiesDialogOpened: false});
	}

	changeTheme(theme) {
		this.setState({theme: theme});
	}

	render() {
		if (this.props.location.pathname == '/sacola' || this.props.location.pathname == '/')
			this.state.lastPage = this.props.location.pathname ;

		return <React.Fragment>
			<ThemeProvider theme={theme[this.state.theme]}>
				<CustomAppBar history={this.props.history} openFilter={this.openFilter} filtered={this.state.filter.order != 1 || this.state.filter.name != ''}/>
				<div style={{display: (this.state.lastPage=='/') ? 'block' : 'none'}}>
					<Catalog categoriesLoaded={this.state.categoriesLoaded} categories={this.state.categories}
						productsLoaded={this.state.productsLoaded} products={this.state.products}
						filter={this.state.filter} openFilter={this.openFilter} filtered={this.state.filter.order != 1 || this.state.filter.name != ''}
						history={this.props.history} changeTheme={this.changeTheme}/>
				</div>
				<div style={{display: (this.state.lastPage=='/sacola') ? 'block' : 'none'}}>
					{<Bag
						clearBagProducts={this.clearBagProducts}
						history={this.props.history}
						bag={this.state.bag}
						deleteProductFromBag={this.deleteProductFromBag}
					/>}
				</div>
				<BottomNav location={this.props.location} history={this.props.history} bagQnt={this.state.bag.products.length}/>
				<InternalPage location={this.props.location} history={this.props.history} lastPage={this.state.lastPage}/>
				<ProductDialog addProductToBag={this.addProductToBag} location={this.props.location} history={this.props.history} lastPage={this.state.lastPage}/>
				<FilterDialog open={this.state.filterDialogOpened} filter={this.state.filter} setFilter={this.setFilter} closeFilter={this.closeFilter}/>
				<Snackbar
					autoHideDuration={1000} 
					open={this.state.addedToBag}
					onClose={this.closeAddToBag}
					TransitionComponent={Transition}
					message={`${this.state.addedToBagInfo.name} foi adicionada à sua sacola!`}
				/>
				<CookiesDialog open={this.state.cookiesDialogOpened} history={this.props.history} closeCookiesDialog={this.closeCookiesDialog}/>
			</ThemeProvider>
		</React.Fragment>
	}

}